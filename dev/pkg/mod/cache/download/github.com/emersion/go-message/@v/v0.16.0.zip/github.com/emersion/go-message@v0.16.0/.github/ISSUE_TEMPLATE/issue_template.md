---
name: Bug report or feature request
about: Report a bug or request a new feature
---

<!--

Please read the following before submitting a new issue:

Do NOT create GitHub issues if you have a question about go-message or about MIME in general. Ask questions on IRC in #emersion on Libera Chat.

-->
