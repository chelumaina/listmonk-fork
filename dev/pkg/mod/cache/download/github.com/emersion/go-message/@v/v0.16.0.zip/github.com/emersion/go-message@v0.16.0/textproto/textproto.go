// Package textproto implements low-level manipulation of MIME messages.
package textproto
