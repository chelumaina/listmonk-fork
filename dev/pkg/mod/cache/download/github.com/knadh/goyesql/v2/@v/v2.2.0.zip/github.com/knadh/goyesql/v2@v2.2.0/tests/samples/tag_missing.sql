SELECT * FROM missing;
