
-- name: first


-- name: clone

SELECT * FROM foo;

