// Package extension is a collection of builtin extensions.
package extension
